function [sed1, stri2, spts1, spts2, spnts1, spnts2]=tnrbintersects(tnrb1, tnrb2, p2t1, p2t2)

% tnrbintersects: Get the intersection points of two tri-nurbs surfaces and sort them
% 
% Calling Sequences:
% 
%       [sed1, stri2, spts1, spts2, spnts1, spnts2]=tnrbintersects(tnrb1, tnrb2, p2t1, p2t2)
% 
% INPUTS:
% 
%       tnrb1, tnrb2 - Triangular representation of two nurbs surface.
% 
%       p2t1, p2t2 - The relations from points to triangles of two 
%                     tri-nurbs surface. See also tnrbpts2tri.
%
% OUTPUT: 
%
%      sed1  -  Edges of the triangles of tri-nurbs surface 1 that
%                   intersected with tri-nurbs surface 2.
%
%      stri2   -  Triangles tri-nurbs surface 2 that intersected with 
%                    tri-nurbs surface 1.
%
%       spts1, spts2 - Parametric intersection points of the two surfaces.
%
%       spnts1, spnts2 - Intersection points of the two surfaces.
%
%  Discription:
%   
%      This routine used the 3D triangles to get interections.
%

% The nearest points of the two surfaces
tol=max([tnrb1.seeds(1), tnrb2.seeds(1)]);
[p1, p2]=nearpnts(tnrb1.points, tnrb2.points, tol);

% Intersections of two tri-nurbs surfaces
[ed1, tri2, pts1, pts2, pnts1, pnts2]=tnrbintertri(tnrb1, tnrb2, p2t1, p2t2, p1, p2);

% Sort the intersections of two surfaces and solve losted interections
r=1; ne=size(ed1,1);
while ne>1 && r<100
    % Get a new sorted interections
    [sq, id]=tnrbintersort(tnrb1, ed1, pts1, p2t1);
    
    % Add to sorted data
    sed1{r}=ed1(sq,:);
    stri2{r}=tri2(sq,:);
    spts1{r}=pts1(sq,:);
    spts2{r}=pts2(sq,:);
    spnts1{r}=pnts1(sq,:);
    spnts2{r}=pnts2(sq,:);    
    
    % The remained intersections
    ed1=ed1(id,:);
    tri2=tri2(id,:);
    pts1=pts1(id,:);
    pts2=pts2(id,:);
    pnts1=pnts1(id,:);
    pnts2=pnts2(id,:);
    ne=size(ed1,1);    
    
    [sed1{r}, id]=RemDuplicate(sed1{r});
    stri2{r}=stri2{r}(id,:);
    spts1{r}=spts1{r}(id,:);
    spts2{r}=spts2{r}(id,:);
    spnts1{r}=spnts1{r}(id,:);
    spnts2{r}=spnts2{r}(id,:);
    r=r+1;
end
if r==1
    sed1{r}=[];
    stri2{r}=[];
    spts1{r}=[];
    spts2{r}=[];
    spnts1{r}=[];
    spnts2{r}=[];
end


%% demo
% % The mesh seed length (h0)
% h0=0.5;
% 
% % Create a nurbs sphere
% center=[8,5,2];
% circ=nrbcirc(4, center, 0, pi);
% srf1=nrbrevolve(circ, center, [1,0,0], 2*pi);
% srf2=nrbtestsrf;
% 
% % Transform a nurbs surface into triangular representation
% tnrb1=nrb2tri(srf1, h0);
% tnrb2=nrb2tri(srf2, h0);
% 
% % Get the edges of a tri-nurbs surface that intersected with another tri-nurbs surface
% p2t1=tnrbpts2tri(tnrb1);
% p2t2=tnrbpts2tri(tnrb2);
% 
% % Get the intersection points of two tri-nurbs surfaces and sort them
% [sed1, stri2, spts1, spts2, spnts1, spnts2]=tnrbintersects(tnrb1, tnrb2, p2t1, p2t2);
% nr=length(sed1);
% 
% % Plot the results
% figure; hold on; 
% tnrbplot(tnrb1); 
% tnrbplot(tnrb2); 
% axis equal; view(3); 
% title('Geometric grid'); 
% for r=1:nr
%     plot3(spnts1{r}(:,1), spnts1{r}(:,2), spnts1{r}(:,3), 'ro', 'LineWidth', 1); 
%     plot3(spnts2{r}(:,1), spnts2{r}(:,2), spnts2{r}(:,3), 'y', 'LineWidth', 1); 
% end
% 
% figure; hold on;
% triplot(tnrb1.delaunay, tnrb1.nodes(:,1), tnrb1.nodes(:,2));  
% for r=1:nr
%     plot(spts1{r}(:,1), spts1{r}(:,2), 'k.', 'MarkerSize', 13); 
%     plot(spts1{r}(:,1), spts1{r}(:,2), 'r', 'LineWidth', 1); 
% end
% title('Parametric mesh of surface 1');  
% axis equal; 
% 
% figure; hold on; 
% triplot(tnrb2.delaunay, tnrb2.nodes(:,1), tnrb2.nodes(:,2)); 
% for r=1:nr
%     plot(spts2{r}(:,1), spts2{r}(:,2), 'k.', 'MarkerSize', 13); 
%     plot(spts2{r}(:,1), spts2{r}(:,2), 'r', 'LineWidth', 1); 
% end
% title('Parametric mesh of surface 2'); 
% axis equal;







