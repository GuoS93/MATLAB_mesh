function bp=triboundary(tsrf, p2t)

% triboundary: Get the boundary of a tnrb surface.
% 
% Calling Sequences:
% 
%     bp=tnrbboundary(tsrf, p2t)
% 
% INPUTS:
%
%      tsrf - Triangular representation of a nurbs (tri-nurbs) surface.
%
%      p2t - The relations from points to triangles. See tnrbpts2tri.
%
% OUTPUT:
% 
%    bp - A cell array. Each cell contains a vector of boundary nodes.
%  

% Find edges with only one triangle
tris=(1:tsrf.numbers(2))';
e1=tsrf.delaunay(tris, [1,2]);
e2=tsrf.delaunay(tris, [2,3]);
e3=tsrf.delaunay(tris, [3,1]);
et=sort([e1; e2; e3], 2);%�����߰���������
et=RemDuplicate(et);
eb=[];
for i=1:length(et)
    te1=p2t{et(i,1)};
    te2=p2t{et(i,2)};
    tri=[te1, te2]';
    [~, id]=RemDuplicate(tri);
    tri=tri(~id);
    if length(tri)==1
        eb=[eb; i];
    end
end
et=et(eb,:);

% Sort the boundary edges
r=1; t=2;
k(1:2,1)=et(1,:);
pp=[2, 1];
ne=length(et);
id=true(ne,1);
id(1)=false;
di=zeros(ne,1);
di(1)=1;
for i=2:ne
    p1=find(et(:,1)==k(t));
    p2=find(et(:,2)==k(t));
    j1=1*ones(size(p1));
    j2=2*ones(size(p2));
    p=[p1;p2];
    j=[j1; j2];
    q=find(p~=di(i-1));
    if ~isempty(q) && id(p(q(1)))
        k(t+1)=et(p(q(1)), pp(j(q(1))));
        id(p(q(1)))=false;
        t=t+1;
        di(i)=p(q(1));
    end
    if k(t)==k(1)
        bp{r}=k;
        r=r+1;
        k=find(id);
        if isempty(k)
            break;
        end
        k(1:2,1)=et(k(1),:);
        t=2;
    end
end









