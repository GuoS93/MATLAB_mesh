function tsrfxprt(tsrf)
%export tsrf.points to a file.txt
%input: tsrf - surface represented by triangulars.
fid1=fopen('tsrfpts_.txt','wt');
for i=1:length(tsrf.points)
    for j=1:3
        if j==3
        fprintf(fid1,'%d\n',tsrf.points(i,j));% \n���з�
        else
            fprintf(fid1,'%d\t',tsrf.points(i,j));% \t�Ʊ���
        end
    end
end
fclose(fid1);

fid2=fopen('tsrfdln_.txt','wt');
for i=1:length(tsrf.delaunay)
    for j=1:3
        if j==3
        fprintf(fid2,'%d\n',tsrf.delaunay(i,j));% \n���з�
        else
            fprintf(fid2,'%d\t',tsrf.delaunay(i,j));% \t�Ʊ���
        end
    end
end
fclose(fid2);