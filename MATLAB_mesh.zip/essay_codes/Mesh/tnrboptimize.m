function tsrf=tnrboptimize(tsrf, p2t2, pfix, dt, it, h0, k0, method)

% tnrboptimize: Optimize the triangles of a tri-nurbs surface by Newton's method
% 
% Calling Sequences:
% 
%       tsrf=tnrboptimize(tsrf, p2t2, pfix, dt, it, h0, k0)
% 
% 
%       tsrf - Triangular representation of a nurbs surface.
% 
%       p2t2 - The relations from points to triangles of tri-nurbs 
%                  surface 1. See also tnrbpts2tri.
%
%       pfix - Indexes of the fixed nodes.���̶��߽磩
%
%       dt  -  Time step.
%       
%       it   -  Iteration times.
%       h0  -  Mesh seed length.
%
%       k0  -  Force factor.
%
%
% OUTPUT: 
%
%       tsrf - The tri-nurbs surface after Optimization.
%


srf=tsrf.nurbs;
pop=true(tsrf.numbers(1),1);%����N*1��ȫ1����
pop(pfix)=false;%�̶��㴦Ϊ0
pop=sort(find(pop));%�ҵ�pop�з�0Ԫ��λ��������
np=length(pop);%�ǹ̶���ĸ���
F1=zeros(np, 3);
dsrf=nrbderiv(srf);
X2=zeros(3,1);
for k=1:it
    for i=1:np
        X1=tsrf.points(pop(i), :);%��pop(i)�����ϵ�
        x1=tsrf.nodes(pop(i), :);%��Ӧ�Ľڵ�
        F1(i,:)=k0*tnrbforce(tsrf, p2t2, pop(i), h0);        
        for j=1:3
            if method==1
                X2(j)=X1(j)+dt*F1(i,j);%F1>0������F1<0����
            elseif method==2
                X2(j)=X1(j)+dt*V1(i,j)+F1(i,j)*dt^2/2;                
            end
        end
        [x2, X2]=nrbsrfreverse(srf, dsrf, x1, X2);%ţ�ٷ��󽻵�
        tsrf.points(pop(i), :)=X2;
        tsrf.nodes(pop(i), :)=x2;
    end
end

%% demo
% % The mesh seed length (h0) and force facter (k0)
% h0=1.8; k0=1;
% 
% % Create a plane surface
% af=0;
% crv1=nrbcirc(8, [0,0], af, pi-af);
% crv2=nrbcirc(8, [0,0], pi+af, 2*pi-af);
% crv2=nrbreverse(crv2);
% srf=nrbruled(crv1, crv2);
% % srf=nrbrevolve(crv1, [0,0,0], [1,0,0], pi);
% 
% % Transform a nurbs surface into triangular representation
% tsrf=nrb2tri(srf, h0);
% 
% figure; hold on; 
% tnrbplot(tsrf);
% axis equal; view(3);
% title('The surface before opimization.');
% 
% % Get the boundary of the tri-nurbs surface
% p2t2=tnrbpts2tri(tsrf);
% bp=triboundary(tsrf, p2t2);
% bp=bp{1};
% 
% % Optimize the triangles
% dt=0.1; it=10;
% pfix=sort(RemDuplicate(bp));
% tsrf=tnrboptimize(tsrf, p2t2, pfix, dt, it, h0, k0);
% 
% % Plot results
% figure; hold on; 
% tnrbplot(tsrf);
% plot3(tsrf.points(bp,1), tsrf.points(bp,2), tsrf.points(bp,3), 'r')
% axis equal; view(3);
% title('The surface after opimization.');




