clear
% % The mesh seed length (h0)
h0=0.1;
% 
%Create a nurbs sphere
circ=nrbcirc(1, [0,0], 0, pi);
srf=nrbrevolve(circ, [0,0,0], [1,0,0], 2*pi);
%srf=nrbtestsrf;

% Transform a nurbs surface into triangular representation
tnrb=nrb2tri(srf, h0);

% Plot the nodes on parametric domain
% figure; hold on;
% plot(tnrb.nodes(:,1), tnrb.nodes(:,2), 'ro');
% axis equal;
% title('Nodes on parametric domain');

% Plot the surface
% figure; hold on;
% nrbplot(srf, [35, 35]);
% view(3);
% shading interp;

% figure; triplot(tnrb.delaunay, tnrb.nodes(:,1), tnrb.nodes(:,2)); 
% title('Parametric mesh');

figure; 
trisurf(tnrb.delaunay, tnrb.points(:,1), tnrb.points(:,2), tnrb.points(:,3));
axis equal;
title('Geometric grid');

%1. �߳���
r=zeros(tnrb.numbers(2),1);
%�����ε�Ԫ��С�ڽ�
alpha=zeros(tnrb.numbers(2),1);

pts=tnrb.points;
dln=tnrb.delaunay;
bad=0;
for i=1:tnrb.numbers(2)
    
    l1=sqrt((pts(dln(i,1),1)-pts(dln(i,2),1))^2+(pts(dln(i,1),2)-pts(dln(i,2),2))^2+(pts(dln(i,1),3)-pts(dln(i,2),3))^2);
    l2=sqrt((pts(dln(i,2),1)-pts(dln(i,3),1))^2+(pts(dln(i,2),2)-pts(dln(i,3),2))^2+(pts(dln(i,2),3)-pts(dln(i,3),3))^2);
    l3=sqrt((pts(dln(i,1),1)-pts(dln(i,3),1))^2+(pts(dln(i,1),2)-pts(dln(i,3),2))^2+(pts(dln(i,1),3)-pts(dln(i,3),3))^2);
    lmx=max([l1,l2,l3]);
    lmn=min([l1,l2,l3]);
    r(i)=lmx/lmn;
    a1=acos((l2^2+l3^2-l1^2)/(2*l2*l3));
    a2=acos((l1^2+l3^2-l2^2)/(2*l1*l3));
    a3=acos((l1^2+l2^2-l3^2)/(2*l1*l2));
    alpha(i)=min([a1,a2,a3]);
    alpha(i)=alpha(i)*(180/pi);
    if alpha(i)<50
        bad=bad+1;
    end
end


%�Ż� 
 k0=1;
% Get the boundary of the tri-nurbs surface
p2t2=tnrbpts2tri(tnrb);
bp=triboundary(tnrb, p2t2);
bp=bp{1};

% Optimize the triangles
dt=0.1; it=1;
pfix=sort(RemDuplicate(bp));
tnrbo=tnrb;
%1. �߳���
ro=zeros(tnrbo.numbers(2),1);
%�����ε�Ԫ��С�ڽ�
alphao=zeros(tnrbo.numbers(2),1);
fig=figure;
t=1;

while (t<10)
tnrbo=tnrboptimize(tnrbo, p2t2, pfix, dt, it, h0, k0);
% tnrbo=tsrf;

tnrbplot(tnrbo);axis equal;
title(['iteration step: ',num2str(t)]);

    %��ȡ��ǰ����
    F = getframe(fig);

    %ת��gifͼƬ,ֻ����256ɫ
    im = frame2im(F);
    [I,map] = rgb2ind(im,256);
    %д�� GIF89a ��ʽ�ļ�    
    if t == 1
        imwrite(I,map,'test.gif','GIF', 'Loopcount',inf,'DelayTime',0.5);
    else
        imwrite(I,map,'test.gif','GIF','WriteMode','append','DelayTime',0.5);
    end  
    drawnow;

pts=tnrbo.points;
dln=tnrbo.delaunay;
bado=0;
for i=1:tnrbo.numbers(2)
    
    l1=sqrt((pts(dln(i,1),1)-pts(dln(i,2),1))^2+(pts(dln(i,1),2)-pts(dln(i,2),2))^2+(pts(dln(i,1),3)-pts(dln(i,2),3))^2);
    l2=sqrt((pts(dln(i,2),1)-pts(dln(i,3),1))^2+(pts(dln(i,2),2)-pts(dln(i,3),2))^2+(pts(dln(i,2),3)-pts(dln(i,3),3))^2);
    l3=sqrt((pts(dln(i,1),1)-pts(dln(i,3),1))^2+(pts(dln(i,1),2)-pts(dln(i,3),2))^2+(pts(dln(i,1),3)-pts(dln(i,3),3))^2);
    lmx=max([l1,l2,l3]);
    lmn=min([l1,l2,l3]);
    ro(i)=lmx/lmn;
    a1=acos((l2^2+l3^2-l1^2)/(2*l2*l3));
    a2=acos((l1^2+l3^2-l2^2)/(2*l1*l3));
    a3=acos((l1^2+l2^2-l3^2)/(2*l1*l2));
    alphao(i)=min([a1,a2,a3]);
    alphao(i)=alphao(i)*(180/pi);
    if alphao(i)<50
        bado=bado+1;
    end
end
t=t+1;
end


tnrbplot(tnrbo);axis equal
title('DistMesh');
hold on;
[dmin,imin]=min(alphao);
plot3([pts(dln(imin,1),1),pts(dln(imin,2),1),pts(dln(imin,3),1)],[pts(dln(imin,1),2),pts(dln(imin,2),2),pts(dln(imin,3),2)],[pts(dln(imin,1),3),pts(dln(imin,2),3),pts(dln(imin,3),3)],'ro')

%Laplacian
it=10;
tnrbol=tnrb;
tnrbol=bdjoin(tnrbol,bp);
for k=1:it
 ptsz=ptsp2tz(tnrbol);
%  for j=1:tnrbol.numbers(1)%�߽�㲻�ƶ�
%      if ~ismember(j,bp)
%      tnrbol.points(j,:)=ptsz(j,:);
%      end
%  end
tnrbol.points=ptsz;
end
%1. �߳���
rol=zeros(tnrbol.numbers(2),1);
%�����ε�Ԫ��С�ڽ�
alphaol=zeros(tnrbol.numbers(2),1);
pts=tnrbol.points;
dln=tnrbol.delaunay;
badol=0;
for i=1:tnrbol.numbers(2)
    l1=sqrt((pts(dln(i,1),1)-pts(dln(i,2),1))^2+(pts(dln(i,1),2)-pts(dln(i,2),2))^2+(pts(dln(i,1),3)-pts(dln(i,2),3))^2);
    l2=sqrt((pts(dln(i,2),1)-pts(dln(i,3),1))^2+(pts(dln(i,2),2)-pts(dln(i,3),2))^2+(pts(dln(i,2),3)-pts(dln(i,3),3))^2);
    l3=sqrt((pts(dln(i,1),1)-pts(dln(i,3),1))^2+(pts(dln(i,1),2)-pts(dln(i,3),2))^2+(pts(dln(i,1),3)-pts(dln(i,3),3))^2);
    lmx=max([l1,l2,l3]);
    lmn=min([l1,l2,l3]);
    rol(i)=lmx/lmn;
    a1=acos((l2^2+l3^2-l1^2)/(2*l2*l3));
    a2=acos((l1^2+l3^2-l2^2)/(2*l1*l3));
    a3=acos((l1^2+l2^2-l3^2)/(2*l1*l2));
    alphaol(i)=min([a1,a2,a3]);
    alphaol(i)=alphaol(i)*(180/pi);
    if alphaol(i)<50
        badol=badol+1;
    end
end

figure; 
trisurf(tnrbol.delaunay, tnrbol.points(:,1), tnrbol.points(:,2), tnrbol.points(:,3));
axis equal;
title('Geometric grid(Laplacian)');
hold on;
[dmin,imin]=min(alphaol);
plot3([pts(dln(imin,1),1),pts(dln(imin,2),1),pts(dln(imin,3),1)],[pts(dln(imin,1),2),pts(dln(imin,2),2),pts(dln(imin,3),2)],[pts(dln(imin,1),3),pts(dln(imin,2),3),pts(dln(imin,3),3)],'ro')

figure;
subplot(2,1,1);
plot(1:tnrb.numbers(2),r,'r');
hold on;
plot(1:tnrb.numbers(2),ro,'b');
hold on;
plot(1:tnrb.numbers(2),rol,'g');
legend('�Ż�ǰ','�Ż���','�Ż���-L');
xlabel('������');
ylabel('�߳���');

subplot(2,1,2);
plot(1:tnrb.numbers(2),alpha,'r');
hold on;
plot(1:tnrb.numbers(2),alphao,'b');
hold on;
plot(1:tnrb.numbers(2),alphaol,'g');
legend('�Ż�ǰ','�Ż���','�Ż���-L');
xlabel('������');
ylabel('��С��(��)');
text(500,40,num2str(bad,'�Ԫ�������Ż�ǰ��:%d'));
text(500,38,num2str(bado,'�Ԫ�������Ż���:%d'));
text(500,30,num2str(badol,'�Ԫ�������Ż���-L��:%d'));



