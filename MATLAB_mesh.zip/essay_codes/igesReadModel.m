%surfacetest1.m plot the igs from CATIA.
%Compile the c-files
%makeIGESmex;

% Load parameter data from IGES-file.
clear;
[Data,~,~,~,~]=iges2matlab('submarine.igs');
[~,s,t]=findindex(Data);
% Plot the IGES object
plotIGES(Data,1);
