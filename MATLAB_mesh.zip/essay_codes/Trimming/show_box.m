%%��ʾ�������ӵ�������
function show_box(X,Y,Z)
%input - X, Y, Z, got from meshgrid.
Nx=size(X,2);Ny=size(Y,1);Nz=size(Z,3);
X1=ones(Nx,Nx);xmin=X(1,1,1);xmax=X(1,Nx,1);
X1(:,:)=xmin;
mesh(X1,reshape(Y(:,1,:),Ny,Nz),reshape(Z(:,1,:),Ny,Nz));
axis equal;hold on;
X2=ones(Nx,Nx);
X2(:,:)=xmax;
mesh(X2,reshape(Y(:,Nx,:),Ny,Nz),reshape(Z(:,Nx,:),Ny,Nz),'FaceAlpha',0);
axis equal;hold on;
Y1(:,:)=ones(Ny,Ny);ymin=Y(1,1,1);ymax=Y(Ny,1,1);
Y1(:,:)=ymin;
mesh(reshape(X(1,:,:),Nx,Nz),Y1,reshape(Z(1,:,:),Nx,Nz));
axis equal;hold on;
Y2(:,:)=ones(Ny,Ny);
Y2(:,:)=ymax;
mesh(reshape(X(Ny,:,:),Nx,Nz),Y2,reshape(Z(Ny,:,:),Nx,Nz),'FaceAlpha',0);
axis equal;hold on;
Z1(:,:)=ones(Nz,Nz);zmin=Z(1,1,1);zmax=Z(1,1,Nz);
Z1(:,:)=zmin;
mesh(reshape(X(:,:,1),Nx,Ny),reshape(Y(:,:,1),Nx,Ny),Z1);
axis equal;hold on;
Z2(:,:)=ones(Nz,Nz);
Z2(:,:)=zmax;
mesh(reshape(X(:,:,Nz),Nx,Ny),reshape(Y(:,:,Nz),Nx,Ny),Z2,'FaceAlpha',0);
axis equal;hold on;
xlabel('x');ylabel('y');zlabel('z');