%Turn the parameter domain to [0,1]
function [ParameterDataNew]=paratrans(ParameterData)
%paratrans: Turn the parameter domain to [0,1]
%INPUT:
%ParameterData - The B-NURBS data extracted from igsfile. 
%                            See also igs2matlab.
%OUTPUT:
%ParameterDataNew - The new B-NURBS data with parameter domain determinated
%                                    in [0,1].
[c,s]=findindex(ParameterData);

ParameterDataNew=ParameterData;
m=size(s,2);
n=size(c,2);
%surface
%Turn the parameter domain of surface to [0,1]
for i=1:m%m������
  u1=ParameterData{1,s(i)}.nurbs.knots{1};
  v1=ParameterData{1,s(i)}.nurbs.knots{2};
  if ParameterData{1,s(i)}.u(1)~=0||ParameterData{1,s(i)}.u(2)~=1
     u1=(u1-ParameterData{1,s(i)}.u(1))./(ParameterData{1,s(i)}.u(2)-ParameterData{1,s(i)}.u(1));
  end
  if ParameterData{1,s(i)}.v(1)~=0||ParameterData{1,s(i)}.v(2)~=1
     v1=(v1-ParameterData{1,s(i)}.v(1))./(ParameterData{1,s(i)}.v(2)-ParameterData{1,s(i)}.v(1));
  end
  ParameterDataNew{1,s(i)}.nurbs.knots{1}=u1;
  ParameterDataNew{1,s(i)}.nurbs.knots{2}=v1;
end

%curve
%Turn the parameter domain of curve to [0,1]

for i=1:n%n������
  v2=ParameterData{1,c(i)}.nurbs.knots;
  if ParameterData{1,c(i)}.v(1)~=0||ParameterData{1,c(i)}.v(2)~=1
     v2=(v2-ParameterData{1,c(i)}.v(1))./(ParameterData{1,c(i)}.v(2)-ParameterData{1,c(i)}.v(1));
  end
  
  ParameterDataNew{1,c(i)}.nurbs.knots=v2;
end

