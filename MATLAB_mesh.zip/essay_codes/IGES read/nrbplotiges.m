function [nrbcrv,nrbsrf,c,s]=nrbplotiges(ParameterData,n1,n2)
%nrbplotiges: Nrbplot the B-NURBS curves and surfaces in the ParameterData.
%INPUT:
%ParameterData - The B-NURBS data extracted from igsfile.                         
%n1,n2 - The numbers of evaluation points in 2 directions.
%OUTPUT:
%nrbcrv - The B-NURBS curves in the ParameterData.
%nrbsrf - The B-NURBS surfaces in the ParameterData.
%c - The indices of B-NURBS curves in the ParameterData.
%s - The indicesof B-NURBS surfaces in the ParameterData.
ParameterData=paratrans(ParameterData);
m=size(ParameterData,2);
count1=0;
if nargin==1
    n1=30;
    n2=30;
end

for i=1:m
    if ParameterData{1,i}.type==126%����
        nrbplot(ParameterData{1,i}.nurbs,n1);
        hold on;   
        count1=count1+1;

    end
end
title('The NURBS curves in ParameterData.');


figure;
count2=0;
for i=1:m 
    if ParameterData{1,i}.type==128
        nrbplot(ParameterData{1,i}.nurbs,[n1,n2]);
        hold on;    
        count2=count2+1;
        s(count2)=i;
    end
end
title('The NURBS surfaces in ParameterData.');

