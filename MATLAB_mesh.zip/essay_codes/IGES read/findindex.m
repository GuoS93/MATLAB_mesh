function [c,s,t]=findindex(ParameterData)
%findindex: Find the indices of the curves and surfaces in ParameterData.
%INPUT:
%ParameterData - The B-NURBS data extracted from igsfile. 
%                            See also igs2matlab.
%OUTPUT:
%c - The indices of curves in ParameterData.
%s - The indices of surfaces in ParameterData.
%t - The indices of trimmed surfaces.
m=size(ParameterData,2);
count1=0;count2=0;count3=0;
for i=1:m
    if ParameterData{1,i}.type==126
        count1=count1+1;
        c(count1)=i;
    end

    if ParameterData{1,i}.type==128
        count2=count2+1;
        s(count2)=i;
    end
    
    if ParameterData{1,i}.type==144
        count3=count3+1;
        t(count3)=i;
    end 
end
